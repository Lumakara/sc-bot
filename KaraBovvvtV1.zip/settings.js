// © ALIP-AI | WhatsApp: 0812-4970-3469
// ⚠️ Do not remove this credit

const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")
global.baileys = require('./package.json').dependencies['@whiskeysockets/baileys'] || 'unknown';
global.internalValidationKey = Buffer.from("LICENSE_VALIDATED").toString('base64');

// SETTING BOT
global.owner = '6285183518016'
global.versi = version
global.namaOwner = "ᴋᴜʟʟᴄᴏᴅᴇʀ"
global.packname = '𝑳̴𝑼͟𝑴̴𝑨͟𝑲̴𝑨͟𝑹̴𝑨 𝑩̴𝑶͟𝑻▾'
global.botname = '𝑳̴𝑼͟𝑴̴𝑨͟𝑲̴𝑨͟𝑹̴𝑨 𝑩̴𝑶͟𝑻▾'
global.botname2 = '𝑳̴𝑼͟𝑴̴𝑨͟𝑲̴𝑨͟𝑹̴𝑨 𝑩̴𝑶͟𝑻▾'

global.tempatDB = 'database.json' // Jangan ubah
global.botSecretKey = "alip-ai" // Jangan ubah

global.custompairing = "JARXXGTG"; /* custom pairing lu */

// PAKASIR GATEWAY, GANTI PAKE PUNYA LU
global.slug = 'lumakara-store';
global.pkasirapikey = 'vv887w32RJ4tTn28xDcmRaop0YYZjKA4';

// ========= HARGA BUY PREM & SEWA BOT =========
global.harga = {
    prem: "5000",
    sewa: "10000"
}

// ======== APIKEY ALIP AI GAUSAH DI UBAH !!! ==============
global.apialip = "https://alipai-api.vercel.app"
global.btc = "https://api.botcahx.eu.org"
global.apikeyalip = "alipainewapikey"
global.velyn = "https://velyn.mom"
global.apikeyvelyn = "zizzmarket"
global.yudzxml = "https://api.yydz.biz.id"
global.apikeyyud = "alipaixyudz"
global.termai = "https://api.termai.cc"
global.apitermai = "alipxtermai"

// ========PANEL SETTING !!!===============
global.egg = "15" // Egg ID
global.nestid = "5" // nest ID
global.loc = "1" // Location ID
global.domain = "https://" // Domain lu
global.apikey = "-" //ptla
global.capikey = "-" //ptlc
// ========================================

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6285183518016"
global.linkGrup = "https://chat.whatsapp.com/E30CiX58JWG2t720dEJiu5"

// Delay Jpm & Pushctc || 1000 = 1detik
global.delayJpm = 10000
global.delayPushkontak = 15000

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029VbAMjf51SWsyK2NmbC12"
global.idSaluran = "120363418916194798@newsletter"
global.namaSaluran = "Lumakara Official"


// Settings All Payment
global.dana = "085183518016" // ubah jadi nomor dana kalian 
global.gopay = "085183518016" // ubah jadi nomor gopay kalian


// Settings Image Url
global.image = {
// gambar menu awal
menu: "http://aliceecdn.vercel.app/file/8b5c5ab883.jpg",
// menu v 2
menuv2: "http://aliceecdn.vercel.app/file/d5df6f0dcd.jpg", 
//banner welcome 
welcome: "https://img1.pixhost.to/images/9307/649554070_media.jpg", 
//banner left 
left: "https://img1.pixhost.to/images/9307/649554070_media.jpg", 
// logo saat bot reply pesan
reply: "https://files.catbox.moe/fgybos.webpg", 
levelup: "https://img1.pixhost.to/images/9319/649726402_media.jpg", 
// ubah jadi qris kalian
qris: "https://c.termai.cc/i176/pXRX3.jpg"
}
// Message Command 
global.mess = {
limit: `💋 *Limit habis, sayang~* 😔\nKetik *.claim* buat klaim bonus... atau biar aku bantu lebih? 😉\nAtau mau upgrade ke Premium pakai *.buyprem*? Akan ada spesial treat~ ✨`
owner: `🔥 *Khusus Owner-ku saja~* 🚷\nHanya *Sang Pemilik* yang boleh sentuh fitur ini... 💋`
verifikasi: `🔒 *Verifikasi dulu, darling~* 😘\nKetik *.daftar* biar kita bisa mulai petualangan seru~ 🎠`
admin: `👠 *Hanya untuk Admin~* 💼\nFitur ini terlalu panas untuk yang lain... cuma *Admin Grup* yang boleh~ 🔥`
botAdmin: `🦋 *Jadikan aku Admin dulu~* 📛\nAku harus punya kuasa di grup ini... biar bisa melayani dengan maksimal~ 💞`
group: `🎪 *Butuh suasana ramai~* 🎭\nFitur ini hanya bisa di *Grup*... biar kita bisa panas bareng~ 😈`
private: `🛏️  *Hanya untuk kita berdua~* 💌\nFitur ini eksklusif untuk *Chat Pribadi*... biar lebih intim~ 🌹`
prem: `💋 *Khusus untuk Premium~* 🥂\nFitur spesial hanya untuk *User Premium*... mau merasakan nikmatnya? 💎\nKetik *.prem* untuk upgrade dan dapatkan semua akses istimewa~ 🔥`
wait: `⏳ *Tunggu sebentar, sayang~* 😌\nBiarkan aku proses permintaanmu dengan sempurna... 💖`
error: `😢 *Ada gangguan nih~* ⚡\nTapi jangan khawatir, kita coba lagi nanti ya? Aku pasti bantu sampai puas~ 💋`
done: `🎊 *Sudah selesai, honey~* 💃\nProsesnya tuntas... dan semuanya sempurna untukmu~ ✨`
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
